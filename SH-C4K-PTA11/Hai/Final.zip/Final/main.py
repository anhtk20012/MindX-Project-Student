import sys, os
from PyQt6 import QtCore
from PyQt6.QtWidgets import QApplication, QWidget
from src import welcome

from pathlib import Path
os.chdir(Path(__file__).parent)

class Signal(QWidget):
    welcome = QtCore.pyqtSignal()
    
class Main_App(QWidget):
    def __init__(self):
        self.signal = Signal()
        self.welcome = welcome.Welcome(self.signal)
        
        self.signal.welcome.connect(self.welcome.welcome_open)
        
    def main_show(self):
        self.signal.welcome.emit()
        
if __name__ == "__main__":
    app = QApplication(sys.argv)
    windows = Main_App()
    windows.main_show
    app.exec()